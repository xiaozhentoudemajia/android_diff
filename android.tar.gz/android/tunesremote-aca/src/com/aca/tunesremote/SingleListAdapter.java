package com.aca.tunesremote;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Administrator on 2017/7/11.
 */

public class SingleListAdapter extends BaseAdapter {
    public static final String TAG = SingleListAdapter.class.toString();
    protected ArrayList<String> list = new ArrayList<String>();
    private Activity activity;
    private LayoutInflater inflater = null;
    private int select = -1;

    public SingleListAdapter(Activity context) {
        this.activity = context;
        inflater = LayoutInflater.from(context);
        Log.w(TAG, "SingleListAdapter");
    }

    public void setList(ArrayList<String> names) {
        this.list = names;
    }

    @Override
    public int getCount() {
        Log.w(TAG, "getCount");
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;

        if(convertView == null) {
            convertView = inflater.inflate(R.layout.list_item_view, null);
            holder = new ViewHolder();
            holder.tv = (TextView)convertView.findViewById(R.id.list_item_tv);
            holder.cb = (CheckBox)convertView.findViewById(R.id.list_item_cb);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.tv.setText(list.get(position));

        holder.cb.setId(position);
        holder.cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    if (select != -1) {
                        CheckBox tempCheckBox = (CheckBox) activity.findViewById(select);
                        if (tempCheckBox != null) {
                            tempCheckBox.setChecked(false);
                        }
                    }
                    select = buttonView.getId();
                }
            }
        });

        Log.d(TAG, "select: "+select);
        Log.d(TAG, "position: "+position);
        if (select == position)
            holder.cb.setChecked(true);
        else
            holder.cb.setChecked(false);

        return convertView;
    }

    public static class ViewHolder {
        TextView tv;
        CheckBox cb;
    }

    public int getSelect() {
        return select;
    }
}
