package com.aca.tunesremote;

import android.app.ActionBar;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.aca.tunesremote.daap.Library;
import com.aca.tunesremote.daap.Response;
import com.aca.tunesremote.daap.Session;
import com.aca.tunesremote.SingleListAdapter;
import com.aca.tunesremote.daap.Status;
import com.aca.tunesremote.util.Constants;
import com.aca.tunesremote.util.ThreadExecutor;

import java.util.ArrayList;
import java.util.List;
import java.util.LinkedList;

/**
 * Created by Administrator on 2017/7/10.
 */

public class RenameActivity extends Activity {
    public static final String TAG = RenameActivity.class.toString();
    protected  String curHost;
    protected  String curHostLibrary;
    TextView rename_empty;
    ListView rename_list;
    ArrayList<String> nameList;
    //namelistAdapter adapter;
    SingleListAdapter adapter;

    private BackendService backend;
    private Session session;
    private Library library;
    public ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name,final  IBinder service) {
            backend = ((BackendService.BackendBinder) service).getService();
            ThreadExecutor.runTask(new Runnable() {
                public void run() {
                    int timeout = 0;
                    try {
                        backend = ((BackendService.BackendBinder) service).getService();
                        if (null != backend) {
                            do {
                                Thread.sleep(300);
                                SessionWrapper sessionWrapper = backend.getSession(curHost);
                                if (null != sessionWrapper) {
                                    if (!sessionWrapper.isTimeout()) {
                                        session = sessionWrapper.getSession(curHost);
                                    }else{
                                        timeout = SpeaksActivity.tryCnt;
                                    }
                                    Log.d(TAG, sessionWrapper.toString());
                                } else {
                                    Log.w(TAG, "waiting session to been created");
                                }
                                timeout++;
                                if (timeout > SpeaksActivity.tryCnt) {
                                    if (null == session) {
                                        session = backend.getSession(curHost, curHostLibrary);
                                        Log.w(TAG, "WifiConfigActivity force create session ");
                                    }
                                    break;
                                }
                            } while ((null == session) && (null != backend));

                            if(null != session){
                                resultsUpdated.sendEmptyMessage(Constants.MSG_WHAT_SESSION_READY);
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.e(TAG, "SpeaksActivity get session error:" + e.getMessage());
                    }
                }
            });

            try {
                backend = ((BackendService.BackendBinder) service).getService();

                Log.w(TAG, "onServiceConnected for RenameActivity");

                session = backend.getSession();
                if (session == null) {
                    return;
                }

                //library = new Library(session);
                //library.readNameList(adapter);

            } catch (Exception e) {
                Log.e(TAG, "onServiceConnected:"+e.getMessage());
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            backend = null;
            session = null;
        }
    };

    @Override
    public void onStart(){
        super.onStart();
        this.bindService(new Intent(this, BackendService.class), connection,
                Context.BIND_AUTO_CREATE);
    }

    @Override
    public void onStop(){
        super.onStop();
        this.unbindService(connection);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);
        curHost = getIntent().getStringExtra(Constants.EXTRA_ADDRESS);
        curHostLibrary  = getIntent().getStringExtra(Constants.EXTRA_LIBRARY);
        ActionBar mActionBar=getActionBar();
        mActionBar.setHomeButtonEnabled(true);
        mActionBar.setDisplayHomeAsUpEnabled(true);
        //mActionBar.setTitle(R.string.control_menu_speakers);
        //mActionBar.setIcon(R.drawable.ic_speaker_group_white);
        setContentView(R.layout.act_rename);
        getWindow().setFeatureInt(Window.FEATURE_INDETERMINATE_PROGRESS, R.layout.progress);
        setProgressBarIndeterminateVisibility(true);
        rename_empty = (TextView)findViewById(R.id.rename_empty);
        rename_list = (ListView)findViewById(R.id.rename_list);

        rename_empty.setVisibility(View.GONE);
        rename_list.setVisibility(View.VISIBLE);

        initList();
    }

    private void initList() {
        Log.w(TAG, "initList");
        nameList = getNameList();
        adapter = new SingleListAdapter(this);
        adapter.setList(nameList);
        //adapter = new namelistAdapter(this);
        rename_list.setAdapter(adapter);

        AdapterView.OnItemClickListener listItemClickListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.w(TAG, "click position "+position);
                if(null == session) {
                    Toast.makeText(RenameActivity.this, "Not ready,please try again later", Toast.LENGTH_LONG).show();
                    return;
                }
                SingleListAdapter.ViewHolder viewHolder = (SingleListAdapter.ViewHolder)view.getTag();
                if(position != adapter.getSelect()) {
                    viewHolder.cb.toggle();
                    session.rename(viewHolder.tv.getText().toString());
                }
            }
        };

        rename_list.setOnItemClickListener(listItemClickListener);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return false;
    }

    public Handler resultsUpdated = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            Log.w(TAG, "handleMessage: "+msg.toString());
            switch (msg.what) {
                case Constants.MSG_WHAT_SESSION_READY:
                    setProgressBarIndeterminateVisibility(false);
                    break;
                default:
                    adapter.notifyDataSetChanged();
                    break;
            }
        }
    };

    private ArrayList<String> getNameList() {
        ArrayList<String> data = new ArrayList<String>();

        data.add(String.format("diningroom"));
        data.add(String.format("kitchen"));
        data.add(String.format("sittingroom"));
        data.add(String.format("bedroom"));
        data.add(String.format("familyroom"));
        data.add(String.format("livingroom"));
        data.add(String.format("study"));

        return data;
    }

    public class namelistAdapter extends SingleListAdapter implements TagListener {
        public namelistAdapter(Activity context) {
            super(context);
            Log.w(TAG, "namelistAdapter ");
        }

        public void foundTag(String tag, final Response resp) {
            if (resp == null) {
                return;
            }

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // add a found search result to name list;
                    if (resp.containsKey("minm")) {
                        try {
                            String name = resp.getString("minm");
                            list.add(resp.getString("minm"));
                            Log.w(TAG, "foundTag: "+name);
                        } catch (Exception e) {
                            Log.w(TAG, "namelistAdapter run:"+e.getMessage());
                        }
                    }
                }
            });
        }

        public void searchDone() {
            Log.w(TAG, "searchDone ");
            resultsUpdated.removeMessages(-1);
            resultsUpdated.sendEmptyMessage(-1);
        }
    }
}
