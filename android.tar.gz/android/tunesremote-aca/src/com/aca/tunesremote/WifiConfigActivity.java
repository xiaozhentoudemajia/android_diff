package com.aca.tunesremote;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.IBinder;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.aca.tunesremote.daap.Session;
import com.aca.tunesremote.daap.Status;
import com.aca.tunesremote.util.Constants;
import com.aca.tunesremote.util.ThreadExecutor;

public class WifiConfigActivity extends Activity {
    public final static String TAG = WifiConfigActivity.class.toString();
    private BackendService backend;
    protected static Session session;
    private String curHost;
    private String curHostLibrary;
    Button setDongle;
    EditText ssidEtext;
    EditText pwdEtext;
    WifiManager wifiManager;
    WifiInfo wifiInfo;
    String selectWifi;

    public ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name,final IBinder service) {
            backend = ((BackendService.BackendBinder) service).getService();

            ThreadExecutor.runTask(new Runnable() {
                public void run() {
                    int timeout = 0;
                    try {
                        backend = ((BackendService.BackendBinder) service).getService();
                        if (null != backend) {
                            do {
                                Thread.sleep(500);
                                SessionWrapper sessionWrapper = backend.getSession(curHost);
                                if (null != sessionWrapper) {
                                    if (!sessionWrapper.isTimeout()) {
                                        session = sessionWrapper.getSession(curHost);
                                    }
                                    Log.d(TAG, sessionWrapper.toString());
                                } else {
                                    Log.w(TAG, "waiting session to been created");
                                }
                                timeout++;
                                if (timeout > SpeaksActivity.tryCnt) {
                                    if (null == session) {
                                        session = backend.getSession(curHost, curHostLibrary);
                                        Log.w(TAG, "WifiConfigActivity force create session ");
                                    }
                                    break;
                                }
                            } while ((null == session) && (null != backend));
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.e(TAG, "SpeaksActivity get session error:" + e.getMessage());
                    }
                }
            });

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            backend = null;
            session = null;
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wifi_config);

        Bundle bundle = this.getIntent().getExtras();
//        ScanResult mStation = (ScanResult)getIntent().getParcelableExtra("scanresult");
//        Log.d(TAG,String.format("ssdi:%s ,capacity:%s",mStation.SSID,mStation.capabilities));
        selectWifi = bundle.getString(this.getString(R.string.ssid_select));
        curHost =  bundle.getString(Constants.EXTRA_ADDRESS);
        curHostLibrary = bundle.getString(Constants.EXTRA_LIBRARY);
        ssidEtext = (EditText) findViewById(R.id.wifi_ssid_edit);
        ssidEtext.setText(selectWifi);
        pwdEtext = (EditText) findViewById(R.id.wifi_pwd_edit);
        setDongle = (Button) findViewById(R.id.wifi_setting_button);
//        setDongle.setVisibility(View.INVISIBLE);
        setDongle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(null == backend){
                    Toast.makeText(WifiConfigActivity.this, "BackendService stop !please try again later", Toast.LENGTH_LONG).show();
                    WifiConfigActivity.this.finish();
                }
                if(null == session) {
                    Toast.makeText(WifiConfigActivity.this, "Not ready,please try again later", Toast.LENGTH_LONG).show();
                }else{
                    ThreadExecutor.runTask(new Runnable() {
                        public void run() {
                            try {
                                session.configWifi(selectWifi,pwdEtext.getText().toString());
                            }catch (Exception e){
                                e.printStackTrace();
                                Log.e(TAG, "onServiceConnected error:"+e.getMessage());
                            }

                        }
                    });

                    Toast.makeText(WifiConfigActivity.this, "Action is done,please waiting", Toast.LENGTH_LONG).show();
                }

            }
        });
//        pwdEtext.addTextChangedListener( new TextWatcher() {
//
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                // TODO Auto-generated method stub
//
//            }
//
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count,
//                                          int after) {
//                // TODO Auto-generated method stub
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable s) {
//                // TODO Auto-generated method stub
//                if (pwdEtext.getText().length() == 8) {
//                    setDongle.setVisibility(View.VISIBLE);
//                }
//            }
//        });
        wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
        wifiInfo = wifiManager.getConnectionInfo();
    }

    @Override
    public void onStart(){
        super.onStart();
        this.bindService(new Intent(this, BackendService.class), connection,
                Context.BIND_AUTO_CREATE);
    }

    @Override
    public void onStop(){
        super.onStop();
        this.unbindService(connection);
    }
}
