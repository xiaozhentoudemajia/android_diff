package com.aca.tunesremote.activity;

import android.app.ActionBar;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.aca.tunesremote.BackendService;
import com.aca.tunesremote.ControlActivity;
import com.aca.tunesremote.R;
import com.aca.tunesremote.SessionWrapper;
import com.aca.tunesremote.daap.Session;
import com.aca.tunesremote.util.Constants;
import com.aca.tunesremote.util.ThreadExecutor;

/**
 * Created by gavin.liu on 2017/8/16.
 */
public abstract class BaseActivity extends FragmentActivity {
    protected final static String TAG = BaseActivity.class.toString();
    public final static int TRY_CNT = 40;
    protected  Session session;
    protected BackendService backend;
    protected  String curHost;
    protected  String curHostLibrary;
    protected  String curHostServices;
    protected ListView list;
    protected BaseAdapter adapter;
    public ViewGroup contentView;

    public ServiceConnection connection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, final IBinder service) {
            backend = ((BackendService.BackendBinder) service).getService();
            syncTaskOnServiceConnect();

            ThreadExecutor.runTask(new Runnable() {

                public void run() {
                    int timeout=0;
                    try {
                        backend = ((BackendService.BackendBinder) service).getService();
                        if (null != backend) {
                            do {
                                Thread.sleep(300);
                                if(null == curHost){
                                    curHost =  backend.getCurHost();
                                    curHostLibrary =  backend.getCurHostLibrary();
                                }

                                Log.d(TAG,"get session for host:"+curHost);
                                SessionWrapper sessionWrapper = backend.getSession(curHost);
                                if (null != sessionWrapper) {
                                    if (!sessionWrapper.isTimeout()) {
                                        session = sessionWrapper.getSession(curHost);
                                    }else{
                                        timeout = TRY_CNT;
                                    }
                                    Log.d(TAG, sessionWrapper.toString());
                                } else {
                                    Log.w(TAG, "waiting session to been created");
                                }

                                timeout++;
                                if(timeout > TRY_CNT){
                                    if(null == session) {
                                        session = backend.getSession(curHost, curHostLibrary);
                                        Log.w(TAG, "force create session ");
                                    }
                                    break;
                                }
                            }while ((null == session)&&(null != backend));

                            asyncTaskOnServiceConnect();

                        }
                    }catch (Exception e){
                        e.printStackTrace();
                        Log.e(TAG, "SpeaksActivity get session error:"+e.getMessage());
                    }

                }
            });
        }

        public void onServiceDisconnected(ComponentName className) {
            // make sure we clean up our handler-specific status
            Log.d(TAG, "onServiceDisconnected");
            backend = null;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);
        curHost = getIntent().getStringExtra(Constants.EXTRA_ADDRESS);
        curHostLibrary  = getIntent().getStringExtra(Constants.EXTRA_LIBRARY);
        curHostServices= getIntent().getStringExtra(Constants.MUSICSERVICE);
        ActionBar mActionBar=getActionBar();
        mActionBar.setHomeButtonEnabled(true);
        mActionBar.setDisplayHomeAsUpEnabled(true);
        if(0==getTitleTextId())
            mActionBar.setTitle(getTitleTextId());

        if(0 != getTitleIconId())
            mActionBar.setIcon(getTitleIconId());

        setContentView(R.layout.act_base);
        contentView=(ViewGroup) findViewById(R.id.base_content_view);
        contentView.addView(View.inflate(this, getContentView(), null));

        this.list = (ListView) this.findViewById(android.R.id.list);
        Button playbarButton = (Button)findViewById(R.id.play_bar);
        playbarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(ControlActivity.class);
            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return false;
    }

    public void startActivity(Class<?> clz) {
        startActivity(new Intent(this, clz));
    }

    public void startActivity(Class<?> clz, Bundle bundle) {
        Intent intent = new Intent(this, clz);
        if (bundle != null) {
            intent.putExtra("bundle", bundle);
        }
        startActivity(intent);
    }

    protected void setListAdapter(BaseAdapter adapter){
        this.list.setAdapter(adapter);
    }

    protected void setListOnItemClickListener(AdapterView.OnItemClickListener listener) {
        this.list.setOnItemClickListener(listener);
    }
    protected abstract int getContentView();

    protected abstract int getTitleTextId();

    protected abstract int getTitleIconId();

    protected abstract void asyncTaskOnServiceConnect();

    protected abstract void syncTaskOnServiceConnect();

}
