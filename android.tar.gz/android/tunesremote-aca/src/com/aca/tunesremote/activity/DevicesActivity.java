package com.aca.tunesremote.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.aca.jmdns.ServiceInfo;
import com.aca.tunesremote.BackendService;
import com.aca.tunesremote.LibraryBrowseActivity;
import com.aca.tunesremote.R;
import com.aca.tunesremote.util.ClickSpan;
import com.aca.tunesremote.util.Constants;
import com.aca.tunesremote.util.ThreadExecutor;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

/**
 * Created by gavin.liu on 2017/8/16.
 */
public class DevicesActivity extends Activity  implements BackendService.ProbeListener, ClickSpan.OnClickListener {

    public final static String TAG = DevicesActivity.class.toString();
    protected BackendService backend;
    protected ListView mList;
    protected DevicesAdapter mDevAdapter;
    protected  String curHost;
    protected  String curHostLibrary;
    protected SharedPreferences prefs;

    public ServiceConnection connection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, final IBinder service) {
            backend = ((BackendService.BackendBinder) service).getService();
            ThreadExecutor.runTask(new Runnable() {

                public void run() {
                    try {
                        backend = ((BackendService.BackendBinder) service).getService();
                        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(DevicesActivity.this);
                        backend.setPrefs(settings);
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            if(null != backend) {
                backend.registerProbeListener(DevicesActivity.this);
                resultsUpdated.sendEmptyMessage(Constants.MSG_WHAT_POBR_START);
                backend.startProbe(false);
            }
        }

        public void onServiceDisconnected(ComponentName className) {
            // make sure we clean up our handler-specific status
            Log.w(TAG, "onServiceDisconnected");
            backend = null;
        }
    };

    public Handler resultsUpdated = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch(msg.what){
                case Constants.MSG_WHAT_POBR_START:
                    mDevAdapter.known.clear();
                    mDevAdapter.notifyDataSetChanged();
                    break;
                case Constants.MSG_WHAT_POBR_CACHE_LIBRARY:
                    HashMap<String, ServiceInfo> map = (HashMap<String, ServiceInfo>)msg.obj;
                    Iterator iter = map.entrySet().iterator();
                    while (iter.hasNext()) {
                        Map.Entry entry = (Map.Entry) iter.next();
                        ServiceInfo val = (ServiceInfo) entry.getValue();
                        mDevAdapter.notifyFound(val);
                    }
                    mDevAdapter.notifyDataSetChanged();
                    break;
                case Constants.MSG_WHAT_POBR_ADD_LIBRARY:
                    ServiceInfo serviceInfo = (ServiceInfo)msg.obj;
                    boolean result = mDevAdapter.notifyFound(serviceInfo);
                    if(result) {
                        resultsUpdated.sendEmptyMessage(-1);
                    }
                    break;
                default:
                    mDevAdapter.notifyDataSetChanged();
                    break;
            }

        }
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.prefs = PreferenceManager.getDefaultSharedPreferences(this);
        setContentView(R.layout.gen_list);

        this.mDevAdapter = new DevicesAdapter(this);

        this.mList = (ListView) this.findViewById(android.R.id.list);
        this.mList.addHeaderView(mDevAdapter.footerView, null, false);
        this.mList.setAdapter(mDevAdapter);

        this.mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if (backend == null)
                    return;
                String caption = ((TextView) view.findViewById(android.R.id.text2)).getText().toString();
                String[] split = caption.split("-");
                if (split.length < 2)
                    return;

                String address = split[0].trim();

                // Use the library name
                String library = ((TextView) view.findViewById(android.R.id.text1)).getText().toString();

                // push off fake result to try login
                // this will start the pairing process if needed
                Intent shell = new Intent();
                shell.putExtra(Constants.EXTRA_ADDRESS, address);
                shell.putExtra(Constants.EXTRA_LIBRARY, library);
                onActivityResult(-1, Activity.RESULT_OK, shell);
                ServiceInfo serviceInfo = (ServiceInfo)mDevAdapter.known.get((int)id);
                String musicService = serviceInfo.getPropertyString(Constants.LIBRARYSERVICE);
//            Log.d(TAG,serviceInfo.toString());
                if(null != backend) {
                    backend.setCurHost(address);
                    backend.setCurHostLibrary(library);
                }
                if(null != musicService) {
                    Intent browserintent = new Intent(DevicesActivity.this,ServiceListActivity.class);
                    browserintent.putExtra(Constants.EXTRA_ADDRESS, address);
                    browserintent.putExtra(Constants.EXTRA_LIBRARY, library);
                    browserintent.putExtra(Constants.MUSICSERVICE, musicService);
                    startActivity(browserintent);
                }else {
                    Intent browserintent = new Intent(DevicesActivity.this,LibraryBrowseActivity.class);
                    browserintent.putExtra(Constants.EXTRA_ADDRESS, address);
                    browserintent.putExtra(Constants.EXTRA_LIBRARY, library);
                    startActivity(browserintent);
                }
            }
        });

        this.mList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (backend == null)
                    return false;

                String caption = ((TextView) view.findViewById(android.R.id.text2)).getText().toString();
                String[] split = caption.split("-");
                if (split.length < 2)
                    return false;

                curHost = split[0].trim();

                // Use the library name
                curHostLibrary = ((TextView) view.findViewById(android.R.id.text1)).getText().toString();
                Log.d(TAG,"longClick:" + curHost);
                return false;
            }
        });


    }

    @Override
    public void onResume() {
        super.onResume();
        try {
            checkWifiState();
        } catch (NullPointerException npe) {
            npe.printStackTrace();
        }
        Log.i(TAG,"onResume");
    }

    @Override
    public void onStart() {
        super.onStart();
        this.bindService(new Intent(this, BackendService.class), connection, Context.BIND_AUTO_CREATE);
        Log.d(TAG,"onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        this.unbindService(connection);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.act_library, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.menu_library_refresh:
                try {
                    if (null != backend) {
                        resultsUpdated.sendEmptyMessage(Constants.MSG_WHAT_POBR_START);
                        backend.startProbe(true);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
                return true;

            case R.id.menu_library_manual:
                LayoutInflater inflater = (LayoutInflater) DevicesActivity.this
                        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                final View view = inflater.inflate(R.layout.dia_text, null);
                final TextView address = (TextView) view.findViewById(android.R.id.text1);
                final TextView code = (TextView) view.findViewById(android.R.id.text2);
                code.setText("0000000000000001");

                new AlertDialog.Builder(DevicesActivity.this).setView(view)
                        .setPositiveButton(R.string.library_manual_pos, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // try connecting to this specific ip address
                                Intent shell = new Intent();
                                shell.putExtra(Constants.EXTRA_ADDRESS, address.getText().toString());
                                shell.putExtra(Constants.EXTRA_LIBRARY, "Manual");
                                shell.putExtra(Constants.EXTRA_CODE, code.getText().toString());
                                onActivityResult(-1, Activity.RESULT_OK, shell);

                            }
                        }).setNegativeButton(R.string.library_manual_neg, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                }).create().show();
                return true;

            case R.id.menu_library_forget:
                new AlertDialog.Builder(DevicesActivity.this).setMessage(R.string.library_forget)
                        .setPositiveButton(R.string.library_forget_pos, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                backend.pairdb.deleteAll();

                            }
                        }).setNegativeButton(R.string.library_forget_neg, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                    }
                }).create().show();
                return true;

//         case R.id.menu_add_device:
//            startActivity(new Intent(this, WifiListActivity.class));
//            return true;

            case R.id.menu_library_about:
                PackageManager packageManager = DevicesActivity.this.getPackageManager();
                try {
                    PackageInfo packInfo = packageManager.getPackageInfo(DevicesActivity.this.getPackageName(), 0);
                    String version = packInfo.versionName;
                    Toast.makeText(DevicesActivity.this, "version:"+ packInfo.versionName+" , code:"+packInfo.versionCode, Toast.LENGTH_LONG).show();
                }catch (Exception e){
                    e.printStackTrace();
                }
                return true;

        }
        return super.onOptionsItemSelected(item);

    }


    @Override
    public void onClick() {

    }

    @Override
    public boolean onServiceinfoCache(HashMap<String, ServiceInfo> map) {
        boolean result = false;
        resultsUpdated.sendMessage(resultsUpdated.obtainMessage(Constants.MSG_WHAT_POBR_CACHE_LIBRARY,map));
        return result;
    }

    @Override
    public boolean onServiceinfoFound(ServiceInfo serviceInfo) {
        resultsUpdated.sendMessage(resultsUpdated.obtainMessage(Constants.MSG_WHAT_POBR_ADD_LIBRARY,serviceInfo));
        Log.d(TAG,serviceInfo.toString());
        return false;
    }

    @Override
    public void OnCheckWifiState() {
        checkWifiState();
    }

    private void createSession(String host,String library,String code){

    }
    /**
     * Gets the current wifi state, and changes the text shown in the header as
     * required.
     */
    public void checkWifiState() {

        WifiManager wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        int intaddr = wifi.getConnectionInfo().getIpAddress();

        View header = mDevAdapter.footerView;
        if (!header.equals(mDevAdapter.footerView))
            Log.e(TAG, "Header is wrong");
        else {
            TextView title = (TextView) header.findViewById(android.R.id.text1);
            TextView explanation = (TextView) header.findViewById(android.R.id.text2);
            ProgressBar progress = (ProgressBar) header.findViewById(R.id.progress);

            if (wifi.getWifiState() == WifiManager.WIFI_STATE_DISABLED) {

                // Wifi is disabled
                title.setText(R.string.wifi_disabled_title);
                explanation.setText(R.string.wifi_disabled);
                ClickSpan.clickify(explanation, "wifi in Settings", this);
                progress.setVisibility(View.GONE);

            } else if (intaddr == 0) {

                // Wifi is enabled, but no network connection
                title.setText(R.string.no_network_title);
                explanation.setText(R.string.no_network);
                ClickSpan.clickify(explanation, "wifi settings", this);
                progress.setVisibility(View.VISIBLE);
            } else {

                // Wifi is enabled and there's a network
                title.setText(R.string.item_network_title);
                explanation.setText(R.string.item_network_caption);
                progress.setVisibility(View.VISIBLE);

            }

        }

    }

    public class DevicesAdapter extends BaseAdapter {

        protected Context context;
        protected LayoutInflater inflater;
        public View footerView;
        protected final LinkedList<ServiceInfo> known = new LinkedList<ServiceInfo>();

        public DevicesAdapter(Context context) {
            this.context = context;
            this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            this.footerView = inflater.inflate(R.layout.item_network, null, false);
        }

        public boolean notifyFound(ServiceInfo serviceInfo) {
            boolean result = false;
            try {
                String libraryName = serviceInfo.getPropertyString("CtlN");
                if (libraryName == null) {
                    libraryName = serviceInfo.getName();
                }
                //Log.i(TAG,"-: "+serviceInfo);
                String online = serviceInfo.getPropertyString("Service");

                // check if we already have this DatabaseId
                for (ServiceInfo service : known) {
                    String knownName = service.getPropertyString("CtlN");
                    if (knownName == null) {
                        knownName = service.getName();
                    }
                    if (libraryName.equalsIgnoreCase(knownName)) {
                        Log.w(TAG, "Already have DatabaseId loaded = " + libraryName);
                        return result;
                    }
                }

                if (!known.contains(serviceInfo)) {
                    known.add(serviceInfo);
                    result = true;
                }
            } catch (Exception e) {
                Log.d(TAG, String.format("Problem getting ZeroConf information %s", e.getMessage()));
            }
            Log.d(TAG,"notifyFound:" + result);
            return result;
        }

        public Object getItem(int position) {
            return known.get(position);
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        public int getCount() {
            return known.size();
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {

            if (convertView == null)
                convertView = inflater.inflate(android.R.layout.simple_list_item_2, parent, false);

            try {
                // fetch the dns txt record to get library info
                final ServiceInfo serviceInfo = (ServiceInfo) this.getItem(position);

                String title = serviceInfo.getPropertyString("CtlN");
                if (title == null) {
                    title = serviceInfo.getName();
                }
                final String addr = serviceInfo.getHostAddresses()[0]; // grab first
                // one
                final String library = String.format("%s - %s", addr, serviceInfo.getPropertyString("DbId"));

//                Log.d(TAG, String.format("ZeroConf Server: %s", serviceInfo.getServer()));
//                Log.d(TAG, String.format("ZeroConf Port: %s", serviceInfo.getPort()));
//                Log.d(TAG, String.format("ZeroConf Title: %s", title));
                Log.d(TAG, String.format("ZeroConf Library: %s", library));

                ((TextView) convertView.findViewById(android.R.id.text1)).setText(title);
                ((TextView) convertView.findViewById(android.R.id.text2)).setText(library);

            } catch (Exception e) {
                Log.d(TAG, String.format("Problem getting ZeroConf information %s", e.getMessage()));
                ((TextView) convertView.findViewById(android.R.id.text1)).setText("Unknown");
                ((TextView) convertView.findViewById(android.R.id.text2)).setText("Unknown");
            }

            return convertView;
        }

    }

    protected class MyTask extends AsyncTask<String, String, String>{

       @Override
       protected void onPreExecute() {
            Log.i(TAG, "onPreExecute() called");
            //textView.setText("loading...");
       }

        @Override
        protected String doInBackground(String... strings) {
            return null;
        }
    }

}
