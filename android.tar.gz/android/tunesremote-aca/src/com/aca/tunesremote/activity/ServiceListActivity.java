package com.aca.tunesremote.activity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.aca.tunesremote.BackendService;
import com.aca.tunesremote.LibraryBrowseActivity;
import com.aca.tunesremote.R;
import com.aca.tunesremote.ShoutcastActivity;
import com.aca.tunesremote.util.Constants;
import com.aca.tunesremote.util.ThreadExecutor;

import java.util.LinkedList;

/**
 * Created by gavin.liu on 2017/8/16.
 */
public class ServiceListActivity extends BaseActivity{
    public final static String TAG = ServiceListActivity.class.toString();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String musicService =new String(curHostServices);
        ServiceAdapter adapter = new ServiceAdapter(this);
        String[] split = musicService.split(",");
        for(int i=0;i<split.length;i++){
            adapter.services.add(new String(split[i]));
        }
        setListAdapter(adapter);
        setListOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if ((backend == null)||(null == session)) {
                    Toast.makeText(ServiceListActivity.this, "Loading...,please try again later", Toast.LENGTH_LONG).show();
                    return;
                }
                String service = ((TextView) view.findViewById(android.R.id.text1)).getText().toString();
                playService(service);
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        this.bindService(new Intent(this, BackendService.class), connection, Context.BIND_AUTO_CREATE);
        Log.d(TAG,"onStart");
    }

    @Override
    public void onStop() {
        super.onStop();
        this.unbindService(connection);
    }

    protected  void playService(final String service){
        if(service.equals(Constants.SPOTIFYSERVICE)){
            ThreadExecutor.runTask(new Runnable() {

                public void run() {
                    try {
                        session.onlinePlay(service);
                        startSpotify();
                    }catch (Exception e){
                        e.printStackTrace();
                        Toast.makeText(ServiceListActivity.this, "Reauest failed!", Toast.LENGTH_LONG).show();
                    }
                }
            });
            //session.onlinePlay(service);

        }else if(service.equals(Constants.SHOUTCASTSERVICE)){
            Intent intentShoutcast = new Intent(ServiceListActivity.this, ShoutcastActivity.class);
            intentShoutcast.putExtra(Constants.EXTRA_ADDRESS, curHost);
            intentShoutcast.putExtra(Constants.EXTRA_LIBRARY, curHostLibrary);
            startActivity(intentShoutcast);

        }else if(service.equals(Constants.DLNASERVICE)){
            ThreadExecutor.runTask(new Runnable() {
                public void run() {
                    try {
                        session.onlinePlay(service);
                        startBubbleupnp();
                    }catch (Exception e){
                        e.printStackTrace();
                        Toast.makeText(ServiceListActivity.this, "Reauest failed!", Toast.LENGTH_LONG).show();
                    }
                }
            });
            //session.onlinePlay(service);
        }else if(service.equals(Constants.MYMUSICSERVICE)){
            Intent intentBrowser = new Intent(ServiceListActivity.this, LibraryBrowseActivity.class);
            intentBrowser.putExtra(Constants.EXTRA_ADDRESS, curHost);
            intentBrowser.putExtra(Constants.EXTRA_LIBRARY, curHostLibrary);
            startActivity(intentBrowser);
        }else if(service.equals(Constants.BLUETOOTHSERVICE)){
            ThreadExecutor.runTask(new Runnable() {
                public void run() {
                    try {
                        session.onlinePlay(service);
                        Intent intent =  new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                        startActivity(intent);
                    }catch (Exception e){
                        e.printStackTrace();
                        Toast.makeText(ServiceListActivity.this, "Reauest failed!", Toast.LENGTH_LONG).show();
                    }
                }
            });
//          session.onlinePlay(service);
//          Intent intent =  new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
//          startActivity(intent);
        }

    }

    private void startSpotify(){
        //Intent inten;
        PackageManager packageManager = this.getPackageManager();
        Intent intent = packageManager.getLaunchIntentForPackage("com.spotify.music");
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED | Intent.FLAG_ACTIVITY_CLEAR_TOP) ;
        this.startActivity(intent);
    }

    public void startBubbleupnp(){
        //Intent inten;
        PackageManager packageManager = this.getPackageManager();
        Intent intent = packageManager.getLaunchIntentForPackage("com.bubblesoft.android.bubbleupnp");
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED | Intent.FLAG_ACTIVITY_CLEAR_TOP) ;
        this.startActivity(intent);
    }


    @Override
    protected int getContentView() {
        return R.layout.gen_list;
    }

    @Override
    protected int getTitleTextId() {
        return R.string.music_services;
    }

    @Override
    protected int getTitleIconId() {
        return R.drawable.ic_library_music_white_18dp;
    }

    @Override
    protected void asyncTaskOnServiceConnect() {

    }

    @Override
    protected void syncTaskOnServiceConnect() {

    }

    public class ServiceAdapter extends BaseAdapter {

        protected Context context;
        protected LayoutInflater inflater;
        protected final LinkedList<String> services = new LinkedList<String>();

        public ServiceAdapter(Context context) {
            this.context = context;
            this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        public Object getItem(int position) {
            return services.get(position);
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        public int getCount() {
            return services.size();
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            TextView itemText;
            ImageView itemIcon;
            if (convertView == null)
                convertView = inflater.inflate(android.R.layout.activity_list_item, parent, false);
            final String service = (String) this.getItem(position);
            //convertView.setPaddingRelative();
            itemIcon=((ImageView) convertView.findViewById(android.R.id.icon));
            itemText = ((TextView) convertView.findViewById(android.R.id.text1));
            itemText.setText(service);
            itemText.setTextSize(24);
            if(service.equals(Constants.SPOTIFYSERVICE)){
                itemIcon.setImageResource(R.drawable.ic_cloud_queue_white_24dp);
            }else if(service.equals(Constants.SHOUTCASTSERVICE)){
                itemIcon.setImageResource(R.drawable.ic_radio_white_24dp);

            }else if(service.equals(Constants.DLNASERVICE)){
                itemIcon.setImageResource(R.drawable.ic_phonelink_ring_white_24dp);

            }else if(service.equals(Constants.MYMUSICSERVICE)){
                itemIcon.setImageResource(R.drawable.ic_usb_white_24dp);
            }else if(service.equals(Constants.BLUETOOTHSERVICE)){
                itemIcon.setImageResource(R.drawable.ic_bluetooth_white_24dp);
            }else
                itemIcon.setImageResource(R.drawable.ic_search_category_music_artist);

            return convertView;
        }

    }
}
