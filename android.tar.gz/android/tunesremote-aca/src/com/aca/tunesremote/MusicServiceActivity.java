/*
    TunesRemote+ - http://code.google.com/p/tunesremote-plus/

    Copyright (C) 2008 Jeffrey Sharkey, http://jsharkey.org/
    Copyright (C) 2010 TunesRemote+, http://code.google.com/p/tunesremote-plus/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    The Initial Developer of the Original Code is Jeffrey Sharkey.
    Portions created by Jeffrey Sharkey are
    Copyright (C) 2008. Jeffrey Sharkey, http://jsharkey.org/
    All Rights Reserved.
 */

package com.aca.tunesremote;

import android.app.ActionBar;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.aca.tunesremote.daap.Session;
import com.aca.tunesremote.util.Constants;
import com.aca.tunesremote.util.ThreadExecutor;

import java.util.LinkedList;

/**
 * Show a list of all libraries found on local wifi network. Should have refresh
 * button easly accessibly, and also detect wifi issues.
 */
public class MusicServiceActivity extends FragmentActivity {
   public final static String TAG = MusicServiceActivity.class.toString();
   protected static Session session;
   private BackendService backend;
   protected  String curHost;
   protected  String curHostLibrary;
    protected  String curHostServices;
   protected ListView list;
   protected ServiceAdapter adapter;

   public ServiceConnection connection = new ServiceConnection() {
       public void onServiceConnected(ComponentName className, final IBinder service) {
           backend = ((BackendService.BackendBinder) service).getService();

           ThreadExecutor.runTask(new Runnable() {

            public void run() {
                int timeout=0;
                try {
                    backend = ((BackendService.BackendBinder) service).getService();
                    if (null != backend) {
                        do {
                            Thread.sleep(300);
                            if(null == curHost){
                                curHost =  backend.getCurHost();
                                curHostLibrary =  backend.getCurHostLibrary();
                            }else {
                                backend.setCurHost(curHost);
                                backend.setCurHostLibrary(curHostLibrary);
                                backend.setCurHostServices(curHostServices);
                            }
                            Log.d(TAG,"get session for host:"+curHost);
                            SessionWrapper sessionWrapper = backend.getSession(curHost);
                            if (null != sessionWrapper) {
                                if (!sessionWrapper.isTimeout()) {
                                    session = sessionWrapper.getSession(curHost);
                                }else{
                                    timeout = SpeaksActivity.tryCnt;
                                }
                                Log.d(TAG, sessionWrapper.toString());
                            } else {
                                Log.w(TAG, "waiting session to been created");
                            }

                            timeout++;
                            if(timeout > SpeaksActivity.tryCnt){
                                if(null == session) {
                                    session = backend.getSession(curHost, curHostLibrary);
                                    Log.w(TAG, "force create session ");
                                }
                                break;
                            }
                        }while ((null == session)&&(null != backend));
                        Log.d(TAG, session.toString());
                        backend.updateCurSession(session);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                    Log.e(TAG, "get session error:"+e.getMessage());
                }

            }
           });
      }

      public void onServiceDisconnected(ComponentName className) {
         // make sure we clean up our handler-specific status
         Log.d(TAG, "onServiceDisconnected");
         backend = null;
      }
   };


   @Override
   public void onResume() {
      super.onResume();
   }

   @Override
   public void onStart() {
      super.onStart();
      this.bindService(new Intent(this, BackendService.class), connection, Context.BIND_AUTO_CREATE);
   }

   @Override
   public void onStop() {
      super.onStop();
      this.unbindService(connection);
   }

   @Override
   public void onDestroy() {
      super.onDestroy();
   }

   @Override
   public void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      curHost = getIntent().getStringExtra(Constants.EXTRA_ADDRESS);
      curHostLibrary  = getIntent().getStringExtra(Constants.EXTRA_LIBRARY);
      curHostServices= getIntent().getStringExtra(Constants.MUSICSERVICE);
       String musicService =new String(curHostServices);
       ActionBar mActionBar=getActionBar();
      mActionBar.setHomeButtonEnabled(true);
      mActionBar.setDisplayHomeAsUpEnabled(true);
      mActionBar.setTitle(R.string.music_services);
      mActionBar.setIcon(R.drawable.ic_library_music_white_18dp);
      setContentView(R.layout.services_list);
      this.adapter = new ServiceAdapter(this);
      String[] split = musicService.split(",");
      for(int i=0;i<split.length;i++){
         this.adapter.services.add(new String(split[i]));
      }

      this.list = (ListView) this.findViewById(android.R.id.list);
      this.list.setAdapter(adapter);

      this.list.setOnItemClickListener(new OnItemClickListener() {
         public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            // read ip/port from caption if present
            // pass off to backend to try creating pairing session

            if ((backend == null)||(null == session)) {
               Toast.makeText(MusicServiceActivity.this, "Loading...,please try again later", Toast.LENGTH_LONG).show();
               return;
            }
            String service = ((TextView) view.findViewById(android.R.id.text1)).getText().toString();
            playService(service);
         }
      });


   }

   @Override
   public boolean onOptionsItemSelected(MenuItem item) {
      switch (item.getItemId()) {
         case android.R.id.home:
            finish();
            return true;
      }
      return false;
   }

   protected  void playService(final String service){
      if(service.equals(Constants.SPOTIFYSERVICE)){
          ThreadExecutor.runTask(new Runnable() {

              public void run() {
                  try {
                      session.onlinePlay(service);
                      startSpotify();
                  }catch (Exception e){
                      e.printStackTrace();
                      Toast.makeText(MusicServiceActivity.this, "Reauest failed!", Toast.LENGTH_LONG).show();
                  }
              }
          });
         //session.onlinePlay(service);

      }else if(service.equals(Constants.SHOUTCASTSERVICE)){
         Intent intentShoutcast = new Intent(MusicServiceActivity.this, ShoutcastActivity.class);
         intentShoutcast.putExtra(Constants.EXTRA_ADDRESS, curHost);
         intentShoutcast.putExtra(Constants.EXTRA_LIBRARY, curHostLibrary);
         startActivity(intentShoutcast);

      }else if(service.equals(Constants.DLNASERVICE)){
          ThreadExecutor.runTask(new Runnable() {
              public void run() {
                  try {
                      session.onlinePlay(service);
                      startBubbleupnp();
                  }catch (Exception e){
                      e.printStackTrace();
                      Toast.makeText(MusicServiceActivity.this, "Reauest failed!", Toast.LENGTH_LONG).show();
                  }
              }
          });
         //session.onlinePlay(service);
      }else if(service.equals(Constants.MYMUSICSERVICE)){
         Intent intentBrowser = new Intent(MusicServiceActivity.this, LibraryBrowseActivity.class);
         intentBrowser.putExtra(Constants.EXTRA_ADDRESS, curHost);
         intentBrowser.putExtra(Constants.EXTRA_LIBRARY, curHostLibrary);
         startActivity(intentBrowser);
      }else if(service.equals(Constants.BLUETOOTHSERVICE)){
          ThreadExecutor.runTask(new Runnable() {
              public void run() {
                  try {
                      session.onlinePlay(service);
                      Intent intent =  new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                      startActivity(intent);
                  }catch (Exception e){
                      e.printStackTrace();
                      Toast.makeText(MusicServiceActivity.this, "Reauest failed!", Toast.LENGTH_LONG).show();
                  }
              }
          });
//          session.onlinePlay(service);
//          Intent intent =  new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
//          startActivity(intent);
      }

   }

   private void startSpotify(){
      //Intent inten;
      PackageManager packageManager = this.getPackageManager();
      Intent intent = packageManager.getLaunchIntentForPackage("com.spotify.music");
      intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED | Intent.FLAG_ACTIVITY_CLEAR_TOP) ;
      this.startActivity(intent);
   }

   public void startBubbleupnp(){
      //Intent inten;
      PackageManager packageManager = this.getPackageManager();
      Intent intent = packageManager.getLaunchIntentForPackage("com.bubblesoft.android.bubbleupnp");
      intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED | Intent.FLAG_ACTIVITY_CLEAR_TOP) ;
      this.startActivity(intent);
   }

   public class ServiceAdapter extends BaseAdapter {

      protected Context context;
      protected LayoutInflater inflater;
      protected final LinkedList<String> services = new LinkedList<String>();

      public ServiceAdapter(Context context) {
         this.context = context;
         this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
      }

      public Object getItem(int position) {
         return services.get(position);
      }

      @Override
      public boolean hasStableIds() {
         return true;
      }

      public int getCount() {
         return services.size();
      }

      public long getItemId(int position) {
         return position;
      }

      public View getView(int position, View convertView, ViewGroup parent) {
         TextView itemText;
         ImageView itemIcon;
         if (convertView == null)
            convertView = inflater.inflate(android.R.layout.activity_list_item, parent, false);
         final String service = (String) this.getItem(position);
         //convertView.setPaddingRelative();
         itemIcon=((ImageView) convertView.findViewById(android.R.id.icon));
         itemText = ((TextView) convertView.findViewById(android.R.id.text1));
         itemText.setText(service);
         itemText.setTextSize(24);
         if(service.equals(Constants.SPOTIFYSERVICE)){
            itemIcon.setImageResource(R.drawable.ic_cloud_queue_white_24dp);
         }else if(service.equals(Constants.SHOUTCASTSERVICE)){
            itemIcon.setImageResource(R.drawable.ic_radio_white_24dp);

         }else if(service.equals(Constants.DLNASERVICE)){
            itemIcon.setImageResource(R.drawable.ic_phonelink_ring_white_24dp);

         }else if(service.equals(Constants.MYMUSICSERVICE)){
            itemIcon.setImageResource(R.drawable.ic_usb_white_24dp);
         }else if(service.equals(Constants.BLUETOOTHSERVICE)){
            itemIcon.setImageResource(R.drawable.ic_bluetooth_white_24dp);
         }else
            itemIcon.setImageResource(R.drawable.ic_search_category_music_artist);

         return convertView;
      }

   }

}
