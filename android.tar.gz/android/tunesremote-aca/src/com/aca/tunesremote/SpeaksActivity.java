package com.aca.tunesremote;

import android.app.ActionBar;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.aca.tunesremote.daap.Library;
import com.aca.tunesremote.daap.Response;
import com.aca.tunesremote.daap.Session;
import com.aca.tunesremote.daap.Speaker;
import com.aca.tunesremote.daap.Status;
import com.aca.tunesremote.util.Constants;
import com.aca.tunesremote.util.ThreadExecutor;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/7/10.
 */

public class SpeaksActivity extends Activity {
    public static final String TAG = SpeaksActivity.class.toString();
    public static final int NOTIFY_SPEAKERS = 0x80;
    public final static long CACHE_TIME = 10000;
    public final static int tryCnt = 40;
    protected static Session session;
    protected static Status status;
    protected ListView list;
    protected SpeakersAdapter adapter;
    protected  String curHost;
    protected  String curHostLibrary;
    private BackendService backend;
    protected long cachedVolume = -1;
    protected long cachedTime = -1;

    protected List<Speaker> SPEAKERS = new ArrayList<Speaker>();
    public ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, final IBinder service) {
            backend = ((BackendService.BackendBinder) service).getService();

            Log.w(TAG, "onServiceConnected for SpeaksActivity");
            ThreadExecutor.runTask(new Runnable() {
                public void run() {
                    int timeout=0;
                    try {
                        backend = ((BackendService.BackendBinder) service).getService();
                        if (null != backend) {
                            do {
                                Thread.sleep(300);
                                SessionWrapper sessionWrapper =  backend.getSession(curHost);
                                if(null != sessionWrapper){
                                    if(!sessionWrapper.isTimeout()) {
                                        session = sessionWrapper.getSession(curHost);
                                    }else{
                                        timeout = SpeaksActivity.tryCnt;
                                    }
                                    Log.d(TAG,sessionWrapper.toString());
                                }else{
                                    Log.w(TAG,"waiting session to been created");
                                }

                                timeout++;
                                if(timeout > SpeaksActivity.tryCnt){
                                    if(null == session) {
                                        session = backend.getSession(curHost, curHostLibrary);
                                        Log.w(TAG, "SpeaksActivity force create session ");
                                    }
                                    break;
                                }
                            }while ((null == session)&&(null != backend));

                            status = session.singletonStatus(statusUpdate);
                            status.updateHandler(statusUpdate);

                            // push update through to make sure we get updated
                            statusUpdate.sendEmptyMessage(Status.UPDATE_SPEAKERS);
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                        Log.e(TAG, "SpeaksActivity get session error:"+e.getMessage());
                    }

                }
            });
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            backend = null;
            session = null;
        }
    };

    protected Handler statusUpdate = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            // update gui based on severity
            switch (msg.what) {
                case SpeaksActivity.NOTIFY_SPEAKERS:
                    adapter.notifyDataSetChanged();
                    setProgressBarIndeterminateVisibility(false);
                    break;
                case Status.UPDATE_SPEAKERS:
                    ThreadExecutor.runTask(new Runnable() {
                        public void run() {
                            try {
                                if (status == null) {
                                    return;
                                }
                                status.getSpeakers(SPEAKERS);
                                if(SPEAKERS.size() > 0)
                                    statusUpdate.sendEmptyMessage(SpeaksActivity.NOTIFY_SPEAKERS);
                            } catch (Exception e) {
                                Log.e(TAG, "Speaker Exception:" + e.getMessage());
                            }
                        }

                    });
                    break;
            }

            //checkShuffle();
            //checkRepeat();
        }
    };


    @Override
    public void onStart(){
        super.onStart();
        this.bindService(new Intent(this, BackendService.class), connection,
                Context.BIND_AUTO_CREATE);
    }

    @Override
    public void onStop(){
        super.onStop();
        this.unbindService(connection);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);
       // requestWindowFeature(Window.FEATURE_PROGRESS);
        curHost = getIntent().getStringExtra(Constants.EXTRA_ADDRESS);
        curHostLibrary  = getIntent().getStringExtra(Constants.EXTRA_LIBRARY);
        ActionBar mActionBar=getActionBar();
        mActionBar.setHomeButtonEnabled(true);
        mActionBar.setDisplayHomeAsUpEnabled(true);
        mActionBar.setTitle(R.string.control_menu_speakers);
        mActionBar.setIcon(R.drawable.ic_speaker_group_white);
        setContentView(R.layout.gen_list);
        getWindow().setFeatureInt(Window.FEATURE_INDETERMINATE_PROGRESS, R.layout.progress);
        setProgressBarIndeterminateVisibility(true);
        this.adapter = new SpeakersAdapter(this);
        this.list = (ListView) this.findViewById(android.R.id.list);

        //this.list.addHeaderView(adapter.footerView, null, false);
        this.list.setAdapter(adapter);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return false;
    }

    public class SpeakersAdapter extends BaseAdapter {

        protected Context context;
        protected LayoutInflater inflater;
        //public View footerView;

        public SpeakersAdapter(Context context) {
            this.context = context;
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            //this.footerView = inflater.inflate(R.layout.item_network, null, false);
        }

        public int getCount() {
            if (SPEAKERS == null) {
                return 0;
            }
            return SPEAKERS.size();
        }

        public Object getItem(int position) {
            return SPEAKERS.get(position);
        }

        public long getItemId(int position) {
            return position;
        }

        /**
         * Toggles activation of a given speaker and refreshes the view
         * @param active Flag indicating, whether the speaker shall be activated
         * @param speaker the speaker to be activated or deactivated
         */
        public void setSpeakerActive(boolean active, final Speaker speaker) {
            if (speaker == null) {
                return;
            }
            if (status == null) {
                return;
            }
            speaker.setActive(active);

            ThreadExecutor.runTask(new Runnable() {
                public void run() {
                    try {
                        status.setSpeakers(SPEAKERS);
                    } catch (Exception e) {
                        Log.e(TAG, "Speaker Exception:" + e.getMessage());
                    }
                }

            });

            notifyDataSetChanged();
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            try {

                View row;
                if (null == convertView) {
                    row = inflater.inflate(R.layout.item_speaker, null);
                } else {
                    row = convertView;
                }

                /*************************************************************
                 * Find the necessary sub views
                 *************************************************************/
                TextView nameTextview = (TextView) row.findViewById(R.id.speakerNameTextView);
                TextView speakerTypeTextView = (TextView) row.findViewById(R.id.speakerTypeTextView);
                final CheckBox activeCheckBox = (CheckBox) row.findViewById(R.id.speakerActiveCheckBox);
                SeekBar volumeBar = (SeekBar) row.findViewById(R.id.speakerVolumeBar);

                /*************************************************************
                 * Set view properties
                 *************************************************************/
                final Speaker speaker = SPEAKERS.get(position);
                nameTextview.setText(speaker.getName());
                speakerTypeTextView.setText(speaker.isLocalSpeaker() ? R.string.speakers_dialog_computer_speaker
                        : R.string.speakers_dialog_airport_express);
                activeCheckBox.setChecked(speaker.isActive());
                activeCheckBox.setOnClickListener(new View.OnClickListener() {

                    public void onClick(View v) {
                        setSpeakerActive(activeCheckBox.isChecked(), speaker);
                    }
                });
                nameTextview.setOnClickListener(new View.OnClickListener() {

                    public void onClick(View v) {
                        activeCheckBox.toggle();
                        setSpeakerActive(activeCheckBox.isChecked(), speaker);
                    }
                });
                speakerTypeTextView.setOnClickListener(new View.OnClickListener() {

                    public void onClick(View v) {
                        activeCheckBox.toggle();
                        setSpeakerActive(activeCheckBox.isChecked(), speaker);
                    }
                });
                // If the speaker is active, enable the volume bar
                if (speaker.isActive()) {
                    volumeBar.setEnabled(true);
                    volumeBar.setProgress(speaker.getAbsoluteVolume());
                    volumeBar.setOnSeekBarChangeListener(new VolumeSeekBarListener(speaker));
                } else {
                    volumeBar.setEnabled(false);
                    volumeBar.setProgress(0);
                }
                return row;
            } catch (RuntimeException e) {
                Log.e(TAG, "Error when rendering speaker item: ", e);
                throw e;
            }
        }
    }

    public class VolumeSeekBarListener implements SeekBar.OnSeekBarChangeListener {
        private final Speaker speaker;

        public VolumeSeekBarListener(Speaker speaker) {
            this.speaker = speaker;
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
            final int newVolume = seekBar.getProgress();
            ThreadExecutor.runTask(new Runnable() {
                public void run() {
                    try {
                        // Volume of the loudest speaker
                        int maxVolume = 0;
                        // Volume of the second loudest speaker
                        int secondMaxVolume = 0;
                        for (Speaker speaker : SPEAKERS) {
                            if (speaker.getAbsoluteVolume() > maxVolume) {
                                secondMaxVolume = maxVolume;
                                maxVolume = speaker.getAbsoluteVolume();
                            } else if (speaker.getAbsoluteVolume() > secondMaxVolume) {
                                secondMaxVolume = speaker.getAbsoluteVolume();
                            }
                        }
                        // fetch the master volume if necessary
                        checkCachedVolume();
                        int formerVolume = speaker.getAbsoluteVolume();
                        status.setSpeakerVolume(speaker.getId(), newVolume, formerVolume, maxVolume, secondMaxVolume,
                                cachedVolume);
                        speaker.setAbsoluteVolume(newVolume);
                    } catch (Exception e) {
                        Log.e(TAG, "Speaker Exception:" + e.getMessage());
                    }
                }

            });
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        public void onProgressChanged(SeekBar seekBar, int newVolume, boolean fromUser) {
        }
    }

    /**
     * Updates the cachedVolume if necessary
     */
    protected void checkCachedVolume() {
        // try assuming a cached volume instead of requesting it each time
        if (System.currentTimeMillis() - cachedTime > CACHE_TIME) {
            if (status == null) {
                return;
            }
            this.cachedVolume = status.getVolume();
            this.cachedTime = System.currentTimeMillis();
        }
    }

}
