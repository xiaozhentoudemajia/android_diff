package com.aca.tunesremote;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

/**
 * Created by gavin.liu on 2017/7/12.
 */
public class LibraryBrowserViewPager extends ViewPager {
    private boolean noScroll = false;
    public LibraryBrowserViewPager(Context context) {
        super(context);
    }

    public LibraryBrowserViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setNoScroll(boolean noScroll) {
        this.noScroll = noScroll;
    }

    @Override
    public boolean onTouchEvent(MotionEvent arg0) {
        /* return false;//super.onTouchEvent(arg0); */
        if (noScroll)
            return false;
        else
            return super.onTouchEvent(arg0);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent arg0) {
//        int action = arg0.getAction();
//        switch (action & MotionEvent.ACTION_MASK) {
//            case MotionEvent.ACTION_DOWN: {
//            }
//            case MotionEvent.ACTION_MOVE: {
//
//            }
//        }
        if (noScroll)
            return false;
        else
            return super.onInterceptTouchEvent(arg0);
    }

}
