package com.aca.tunesremote;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.IBinder;
import android.util.Log;

import com.aca.jmdns.JmDNS;
import com.aca.jmdns.ServiceEvent;
import com.aca.jmdns.ServiceListener;

import java.io.IOException;
import java.net.InetAddress;


/**
 * Created by gavin.liu on 2017/8/3.
 */
public class DaapUtils extends Service {
    public final static String TAG = DaapUtils.class.toString();
    public final static String TOUCH_ABLE_TYPE = "_touch-able._tcp.local.";
    public final static String DACP_TYPE = "_dacp._tcp.local.";
    public final static String HOSTNAME = "tunesremote";
    private static JmDNS zeroConf = null;
    private static WifiManager.MulticastLock mLock = null;
    private DaapServiceListener mpServiceListener;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        mpServiceListener = new DaapServiceListener();
    }

    public class DaapServiceListener implements ServiceListener{
        @Override
        public void serviceAdded(ServiceEvent event) {
            final String name = event.getName();
        }

        @Override
        public void serviceRemoved(ServiceEvent event) {
            final String name = event.getName();
        }

        @Override
        public void serviceResolved(ServiceEvent event) {
            final String name = event.getName();
        }
    }

    public void startDiscovery() throws Exception {

        if (zeroConf != null)
            stopDiscovery();

        // figure out our wifi address, otherwise bail
        WifiManager wifi = (WifiManager)this.getSystemService(Context.WIFI_SERVICE);

        WifiInfo wifiinfo = wifi.getConnectionInfo();
        int intaddr = wifiinfo.getIpAddress();

        if (intaddr != 0) { // Only worth doing if there's an actual wifi
            // connection

            byte[] byteaddr = new byte[] { (byte) (intaddr & 0xff), (byte) (intaddr >> 8 & 0xff),
                    (byte) (intaddr >> 16 & 0xff), (byte) (intaddr >> 24 & 0xff) };
            InetAddress addr = InetAddress.getByAddress(byteaddr);

            Log.d(TAG, String.format("found intaddr=%d, addr=%s", intaddr, addr.toString()));
            // start multicast lock
            mLock = wifi.createMulticastLock("TunesRemote lock");
            mLock.setReferenceCounted(true);
            mLock.acquire();
            Log.i(TAG,"startProbe");
            zeroConf = JmDNS.create(addr,HOSTNAME);
            zeroConf.addServiceListener(TOUCH_ABLE_TYPE, mpServiceListener);
            zeroConf.addServiceListener(DACP_TYPE,  mpServiceListener);

        }
    }

    public void stopDiscovery(){
        if(null == zeroConf)
            return;
        zeroConf.removeServiceListener(TOUCH_ABLE_TYPE, mpServiceListener);
        zeroConf.removeServiceListener(DACP_TYPE, mpServiceListener);

        try {
            zeroConf.close();
            zeroConf = null;
        } catch (IOException e) {
            Log.d(TAG, String.format("ZeroConf Error: %s", e.getMessage()));
        }
        if(null != mLock)
            mLock.release();
        mLock = null;
    }
}


