package com.aca.tunesremote;

import android.support.v4.app.Fragment;;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * Created by gavin.liu on 2017/8/11.
 */
public class PlaybarFragment extends Fragment implements View.OnClickListener{
    public final static String TAG = PlaybarFragment.class.toString();
    private Context mContext;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.playbar_layout, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
        Log.i(TAG,"onActivityCreated");
        Button button = (Button)getActivity().findViewById(R.id.play_bar);
        button.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        startActivity(new Intent(getActivity(),ControlActivity.class));

    }
}
