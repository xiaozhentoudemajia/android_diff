package aca.com.remote.tunes.daap;

/**
 * Created by gavin.liu on 2017/10/11.
 */
public interface ConnectionResponseListener {
    public void  oResponse(int code, String message);
}
