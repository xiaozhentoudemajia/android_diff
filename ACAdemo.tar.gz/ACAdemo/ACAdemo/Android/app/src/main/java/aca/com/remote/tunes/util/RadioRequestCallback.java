package aca.com.remote.tunes.util;

/**
 * Created by jim.yu on 2017/11/24.
 */

public interface RadioRequestCallback {
    void messageCallback(int type, Object obj);
}
