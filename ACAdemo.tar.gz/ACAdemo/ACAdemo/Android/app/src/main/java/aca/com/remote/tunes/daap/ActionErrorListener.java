package aca.com.remote.tunes.daap;

/**
 * Created by gavin.liu on 2017/8/17.
 */
public interface ActionErrorListener {
    public void  onActionError(int code);
}
